var http= require('http')
var path= require('path')
var fs= require('fs')

// creating server

http.createServer((req,res)=>{
	console.log(`${req.method} request for ${req.url}`)
	
	//to get the .html file
	if(req.url === '/'){
		fs.readFile('./public/index.html', 'UTF-8', (err, html)=>{
			res.writeHead(200, {'Content-Type':'text/html'})
			res.end(html)
		})
		
	}
	
	//to get the css
	else if(req.url.match(/.css$/)){
		var cssPath = path.join(__dirname, 'public', req.url)   //__dirname global obj
		var cssStream = fs.createReadStream(cssPath, 'UTF-8')
		res.writeHead(200, {'Content-Type':'text/css'})
		cssStream.pipe(res)
	}
	
	//to get the image
	
	else if(req.url.match(/.jpg$/)){
		var imgPath = path.join(__dirname, 'public', req.url)   //__dirname global obj
		var imgStream = fs.createReadStream(imgPath)
		res.writeHead(200, {'Content-Type':'image/jpeg'})
		imgStream.pipe(res)
	}
	
	else{
		res.writeHead(404, {'Content-Type':'text/plain'})
		res.end('404- File not found')
	}
}).listen(3300)

console.log('server running on port 3300')