const express = require('express');

const bookRouter = express.Router();

const debug = require('debug')('app:adminRoutes');

const { MongoClient, ObjectID } = require('mongodb');




function router(nav) {

  bookRouter.route('/')
    .get((req, res) => {

      const url = 'mongodb://localhost:27017';
      const dbName = 'libraryApp';
      (async function mongo() {
        let client;
        try {
          client = await MongoClient.connect(url);
          debug('connnected to mongodb server');
          const db = client.db(dbName);
          const col = await db.collection('books');
          const books = await col.find().toArray();
          // const response = await db.collection('books').insertMany(books)
          // res.json(response)
          res.render('booksListView',
            {
              nav,
              title: 'Books -Library',
              books
            });
        } catch (err) {
          debug(err.stack);
        }
        client.close();
      }());
    });



  // get single book;
  bookRouter.route('/:id')
    .get((req, res) => {
      const url = 'mongodb://localhost:27017';
      const dbName = 'libraryApp';

      //const { id } = req.params
      (async function mongo() {
        let client;
        try {
          client = await MongoClient.connect(url);
          debug('connnected to mongodb server');
          const book = await col.findOne({ _id: new ObjectID(id) });
          const db = client.db(dbName);
          const col = await db.collection('books');
          const { id } = req.params;
          res.render(
            'bookView',
            {
              nav,
              title: 'Book - Library',
              book: books[id]
            }
          );
        } catch (err) {
          debug(err.stack);
        }
        client.close();
      }());
    });


  // const id = req.params.id;
  // OR

  return bookRouter;
}
module.exports = router;
