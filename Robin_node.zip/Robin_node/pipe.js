var request = require('request')

var url= request('https://docs.oracle.com/cd/E24152_01/Platform.10-1/ATGMultiApp/html/s0102abouttheoracleatgwebcommerceplat01.html')

var fs= require('fs')
var zlib= require('zlib')

url.pipe(process.stdout)

url.pipe(fs.createWriteStream('./lib/node.html'))
url.pipe(zlib.createGzip()).pipe(fs.createWriteStream('./lib/node.html.gz'))


/*url.pipe(fs.writeFile('./lib/node.html', function(err){
	if(err){
		throw(err)
	}
	console.log('file written')
}))*/