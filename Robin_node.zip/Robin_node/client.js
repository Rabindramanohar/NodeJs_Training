var http= require('http')
var fs= require('fs')

console.log('making a request')

/*var req= http.request('http://nodejs.org/en/',(res)=>{
	console.log(res.statusMessage)
	res.pipe(process.stdout)
})
req.end()*/

var options ={
	host: 'www.robinmanohar.com',
	port: 80,
	path: '/',
	method: 'GET'
}

var req= http.request(options, (res)=>{
	res.pipe(fs.createWriteStream('./lib/robinmanohar.html'))
})
req.end()