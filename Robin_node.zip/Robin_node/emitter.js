var Resource= require('./resource')

//var r= getResource(7)

var r= new Resource(7)

r.on('start', function()
    {
        console.log('function started...')
})

r.on('data', function(d)
    {
        console.log('recieved data...'+d)
})

r.on('end', function(t)
    {
        console.log(`done with : ${t} data events`)
})