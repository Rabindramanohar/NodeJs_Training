/*//console.log(_dirname)
//console.log(__fname)
//console.log(global)

var x= require('path')

console.log('The current path is :'+path.basename(__filename))

console.log(`The curretn filename is ${path.basename(__filename, 'js')}`)

//global
console.log(process.argv)*/

process.stdout.write('hello \n')
process.stdout.write('there...')

process.stdin.on