var EventEmitter = require('events').EventEmitter
var util= require('util')

function Resource(m)
{
    var maxEvents= m
    var self= this

/*var getResource= function(c)
{
    var e= new EventEmitter()*/
    
    process.nextTick(function()                     
    {
        var count = 0
        
        self.emit('start')
        var t= setInterval(function(){
                            self.emit('data', ++count)
                            
                            if(count === maxEvents){
                                    self.emit('end', count)
                                    clearInterval(t)
                                }
        },10)
    })
}

util.inherits(Resource, EventEmitter)

module.exports= Resource

/*var r= getResource(5)

r.on('start', function()
    {
        console.log('function started...')
})

r.on('data', function(d)
    {
        console.log('recieved data...'+d)
})

r.on('end', function(t)
    {
        console.log(`done with : ${t} data events`)
})*/