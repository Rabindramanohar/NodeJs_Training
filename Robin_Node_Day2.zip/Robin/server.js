//building a node server using http

var fs= require('fs')

var https= require('https')

var options = {
	hostname:'en.wikipedia.org',
	port: 443,
	path: '/wiki/George_Washington',
	method: 'GET'
}

var req = https.request(options,(res)=>{
	var responseBody= ''
	console.log('Response from the server')
	console.log(`Server status : ${res.statusCode}`)
	console.log(`Response headers: ${res.headers}`)
	
	res.setEncoding('UTF-8')
	res.once('data', (chunk)=>{
		console.log(chunk)
	})
	
	res.on('data', (chunk)=>{
		console.log(`---Data---${chunk.length}`)
		responseBody+= chunk
	})
	
	res.on('end', (chunk)=>{
		fs.writeFile('./lib/george.html', responseBody, (err)=>{
			if(err){
				throw(err)
			}
			
			console.log('Reading the data from the file...')
		})
	})
	
	res.on('error',(err)=>{
		console.log('ERROR'+err.message)
	})
})
req.end();

//en-wikipedia.org//wiki/George-Washington

/*http.createServer((req, res)=>{
	res.writeHead(200,{'Content-Type':'text/plain'})
	
	if(req.url === './lib/file.txt'){
		fs.createReadStream(__dirname+'app.js')
		.pipe(res)
	}
	else{
		res.end('The response ended')
	}
}).listen(3000)    //.listen(process.env.PORT.env.IP)


console.log(`server listening on port 3000`)*/