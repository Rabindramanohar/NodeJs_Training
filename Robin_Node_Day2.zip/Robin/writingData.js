var fs= require('fs')

var content = `

var x= require('path')
console.log('The current path is :'+path.basename(__filename))
//global
console.log(process.argv)
process.stdout.write('hello \n')
process.stdout.write('there...')

`

/*fs.writeFile('./lib/sample.txt', content.trim(), (err)=>{
             
            if(err)
{
    throw(err)
}
    console.log(`File sample.txt created`)
})*/

// appending data to existin file

/*fs.appendFile('./lib/sample.txt','New text appended to sample.txt', (err)=>
         {
    if(err)
        {
            throw(err)
        }
    console.log('New text added.')
})*/

//Creating directory

if(fs.existsSync('mydir'))
    {
        console.log('directory already existed')
    }
else
    {
fs.mkdir('mydir',(err)=>
        {
if(err)
    {
        throw(err)
    }
    else
        {
            console.log('directory created.')
        }
})
    }