var fs= require('fs')

var stream= fs.createReadStream('./lib/file2.txt','UTF-8') //createReadStream inherited by eventemitter

var data= ' '

stream.once('data', function()
           {
                console.log('\n Reading started...\n')
})
stream.on('data', function(chunk)
         {
    process.stdout.write(`>>>Data>>> ${chunk} and Length is ${chunk.length}\n`)
    
    data+= chunk
})

stream.once('end', function()
           {
                console.log('\n Reading Completed...\n')
})